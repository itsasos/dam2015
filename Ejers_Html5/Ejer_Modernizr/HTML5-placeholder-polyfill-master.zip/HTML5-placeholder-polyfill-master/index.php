<?php
// just needed for the demo web
echo file_get_contents('./web/readme.html');
?>
